@echo off
cd /d "%~dp0"
python -m pip install -r requirements.txt
echo.
echo Installation complete.
echo Copy .streamlit\secrets.toml.example to .streamlit\secrets.toml
echo and add your FoxESS API key.
pause
